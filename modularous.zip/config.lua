return {
    dankpods = true,
    music = true,
    lcbbs = true,
    extra = true
}